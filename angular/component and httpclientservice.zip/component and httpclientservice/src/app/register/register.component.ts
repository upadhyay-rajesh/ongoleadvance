import { Component, OnInit } from '@angular/core';
import { Product } from '../entity/Product';
import { InstagramUser } from '../entity/InstagramUser';
import { ProductService } from '../product.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
	
	mypage:string="Registration Page new";

  private data:Product[];  
  
   private data1:any=[];

    constructor(private myservice:ProductService) {
        this.data = new Array<Product>(
        new Product(1, "Kayak", "Watersports", 275),
        new Product(2, "Lifejacket", "Watersports", 48.95),
        new Product(3, "Soccer Ball", "Soccer", 19.50),
        new Product(4, "Corner Flags", "Soccer", 34.95),
        new Product(5, "Thinking Cap", "Chess", 16));
		
		this.data1 = new Array<InstagramUser>();
    }

    getData(): Product[] {  
        return this.data;
    }
	getData1(): InstagramUser[] {  
        return this.data1;
    }

  ngOnInit(): void {
    this.viewAllProfile();
  }

  viewAllProfile(){
    this.myservice.viewAllUser().subscribe(result=>{console.log(result);
													this.data1=result;});
  }
  
  createProfile(name:any,password:any,email:any,address:any):void{
	  console.log(name+" "+password+" "+email+"  "+address);
	  this.myservice.createProfileUserService(name,password,email,address).subscribe(result=>{console.log(result);
													});
  }

}






















