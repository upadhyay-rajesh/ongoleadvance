export class InstagramUser {

    constructor(public name?: string,
                public password?: string,
                public email?: string,
				public address?:string) {}
}