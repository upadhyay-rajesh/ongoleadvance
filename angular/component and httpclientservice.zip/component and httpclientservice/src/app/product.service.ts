import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import { InstagramUser } from './entity/InstagramUser';

@Injectable()
export class ProductService {

  constructor(private httpclient:HttpClient) { }


  viewAllUser(){
    return  this.httpclient.get("http://localhost:10000/viewAllProfile");
    
  }
  
  createProfileUserService(name:any,password:any,email:any,address:any){
	  let ob1:InstagramUser=new InstagramUser(name,password,email,address);
	  
	  return  this.httpclient.post("http://localhost:10000/createProfile",ob1);
	  
  }
}





















