import { TestBed } from '@angular/core/testing';

import { ProductdeleteService } from './productdelete.service';

describe('ProductdeleteService', () => {
  let service: ProductdeleteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductdeleteService);
  });

  // it('should be created', () => {
  //   expect(service).toBeTruthy();
  // });
});
