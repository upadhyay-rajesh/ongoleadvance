export class Login {
    email:String | undefined;
    password:String | undefined;
}
