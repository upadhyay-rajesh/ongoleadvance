import { Ordermodel } from './ordermodel';

describe('Ordermodel', () => {
  // it('should create an instance', () => {
  //   expect(new Ordermodel()).toBeTruthy();
  // });
});
