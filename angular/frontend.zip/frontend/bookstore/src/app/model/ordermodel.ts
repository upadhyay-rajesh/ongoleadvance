export class Ordermodel {
    orderId:any;
    userId:any;
    productName:any;
    quantity:any;
    price:any;
    Status:any;
    totalPrice:any;
}
