export class Cart {
    cartItemId:any;
    userId:any;
    productName:any;
    quantity:any;
    price:any;
}
