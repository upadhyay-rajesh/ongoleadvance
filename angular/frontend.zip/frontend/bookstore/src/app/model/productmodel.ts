export class Productmodel {
    productId:String|undefined;
    productName:String | undefined;
    price:String|undefined;
    description:String|undefined;
    imageUrl:String|undefined;
    quantity:Number|undefined; 
}