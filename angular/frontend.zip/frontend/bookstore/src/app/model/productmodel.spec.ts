import { Productmodel } from './productmodel';

describe('Productmodel', () => {
  // it('should create an instance', () => {
  //   expect(new Productmodel()).toBeTruthy();
  // });
});
